package com.db.model;

public class FoodCategory {

	
}
