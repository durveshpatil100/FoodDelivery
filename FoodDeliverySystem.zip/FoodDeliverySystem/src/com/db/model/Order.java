package com.db.model;

public class Order {

	private int oid;
	private int total_price;
	private String address;
	private double total_time;
		
	public Order(int oid, int total_price, String address, double total_time) {
		super();
		this.oid = oid;
		this.total_price = total_price;
		this.address = address;
		this.total_time = total_time;
	}
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public int getTotal_price() {
		return total_price;
	}
	public void setTotal_price(int total_price) {
		this.total_price = total_price;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getTotal_time() {
		return total_time;
	}
	public void setTotal_time(double total_time) {
		this.total_time = total_time;
	}
	
	
}
